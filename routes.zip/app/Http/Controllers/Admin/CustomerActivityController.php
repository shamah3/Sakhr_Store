<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerActivityController extends Controller
{
    // Map activity_logs action_type values to human-readable Arabic labels + icon colors
    const ACTION_LABELS = [
        'cart_add'       => ['label' => 'إضافة للسلة',       'color' => 'blue',   'icon' => 'M3 3h2l.4 2M7 13h10l4-8H5.4m1.6 8a2 2 0 100 4 2 2 0 000-4zm8 0a2 2 0 100 4 2 2 0 000-4z'],
        'order_complete' => ['label' => 'إتمام طلب',          'color' => 'green',  'icon' => 'M5 13l4 4L19 7'],
        'wishlist_add'   => ['label' => 'إضافة للمفضلة',      'color' => 'pink',   'icon' => 'M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z'],
        'return_request' => ['label' => 'طلب استرجاع',        'color' => 'orange', 'icon' => 'M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15'],
        'review_add'     => ['label' => 'تقييم منتج',          'color' => 'yellow', 'icon' => 'M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.538 1.118l-3.976-2.888a1 1 0 00-1.176 0l-3.976 2.888c-.783.57-1.838-.197-1.538-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.784-.57-.382-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z'],
        'complaint_add'  => ['label' => 'طلب شكوى',           'color' => 'red',    'icon' => 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z'],
        'login'          => ['label' => 'تسجيل دخول',         'color' => 'purple', 'icon' => 'M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1'],
        'logout'         => ['label' => 'تسجيل خروج',         'color' => 'gray',   'icon' => 'M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1'],
        'create'         => ['label' => 'إضافة',              'color' => 'emerald','icon' => 'M12 4v16m8-8H4'],
        'update'         => ['label' => 'تعديل',              'color' => 'cyan',   'icon' => 'M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z'],
        'delete'         => ['label' => 'حذف',                'color' => 'rose',   'icon' => 'M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16'],
        'payment'        => ['label' => 'عملية دفع',          'color' => 'lime',   'icon' => 'M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z'],
    ];

    public function index(Request $request)
    {
        $query = DB::table('activity_logs')
            ->leftJoin('users', 'activity_logs.user_id', '=', 'users.id')
            ->select(
                'activity_logs.*',
                'users.name as user_name',
                'users.phone as user_phone'
            )
            ->where(function ($q) {
                // Show only customer activities (user_type = customer or no specific role)
                $q->where('activity_logs.user_type', 'customer')
                  ->orWhereNull('activity_logs.user_type');
            });

        if ($request->filled('search')) {
            $s = $request->search;
            $query->where(function ($sub) use ($s) {
                $sub->where('users.name', 'like', "%{$s}%")
                    ->orWhere('users.phone', 'like', "%{$s}%")
                    ->orWhere('activity_logs.description', 'like', "%{$s}%");
            });
        }

        if ($request->filled('action_type')) {
            $query->where('activity_logs.action_type', $request->action_type);
        }

        $activities = $query->orderByDesc('activity_logs.created_at')->paginate(30);

        $stats = [
            'total'          => DB::table('activity_logs')->count(),
            'today'          => DB::table('activity_logs')->whereDate('created_at', today())->count(),
            'cart_adds'      => DB::table('activity_logs')->where('action_type', 'cart_add')->count(),
            'orders'         => DB::table('activity_logs')->where('action_type', 'order_complete')->count(),
        ];

        $actionLabels = self::ACTION_LABELS;

        return view('admin.customer-activities.index', compact('activities', 'stats', 'actionLabels'));
    }
}
